# ODrive fw 0.5.6 cho MKS XDrive Mini (MKS ODrive MINI)

Port của firmware ODrive `fw-v0.5.6` sang board **MKS XDrive Mini / MKS ODrive MINI V1.0**.

**Bản phát hành (2026-09-17):** board `mks-xdrive-mini` — 1 trục (`AXIS_COUNT = 1`,
không có `odrv0.axis1`), AS5047P onboard trên SPI3/GPIO7 với parity check giữ nguyên +
tự xóa `ERRFL`, DC-calib chỉ kiểm tra pha có sensor, `CONFIG_NO_DRM=true` (mount là
`odrv0`), **12 kHz control / 36 kHz PWM** (`CONFIG_PWM_PERIOD_CLOCKS=2333`).
Đã kiểm chứng trên phần cứng: calibration, closed-loop, step response, timing với USB
bận (`control_loop_misc.max_length` 1 348 tick, `pwm_update` kết thúc ~10 500/14 000).
Host: odrivetool **0.5.4** (`pip install odrive==0.5.4`); không dùng 0.5.1 hay 0.6.x.

## 1. Phần cứng (theo schematic MKS ODRIVE MINI V1.0)

| Hạng mục | MKS XDrive Mini | ODrive v3.6-56V |
|---|---|---|
| MCU | STM32F405RGT6 | STM32F405RGT6 |
| Gate driver | **1× DRV8301** (M0) | 2× DRV8301 (M0, M1) |
| Power stage | 6× NTMFS5C628 (1 cầu 3 pha) | 2 cầu |
| Brake resistor | có (LM5109 + 2 FET, JP3) | có |
| Encoder onboard | **AS5047P**, SPI3, CSn = **GPIO7 (PA15)** | không |
| Encoder ABZ ngoài | J5: M0_ENC_A/B/Z | M0 + M1 |
| nFAULT | PD2 | PD2 (chung 2 DRV) |
| M1_nCS (PC13), M1_AH/AL…, M1_SO1/SO2 | **không nối đi đâu** | DRV8301 #2 |
| CAN | PB8/PB9 | giống |
| Shunt | 500 µΩ (giả định giống v3.6) | 500 µΩ |

Pinout MCU y hệt ODrive v3.6 → dùng `HW_VERSION 3.6-56V`, chỉ khác là **không có axis 1**.

Lưu ý: chân CS của AS5047P (PA15 = `GPIO_7_FLT`) đi qua R39 3.3 kΩ + C52 100 pF.

## 2. MKS đã sửa gì trên fw 0.5.1 (repo makerbase-motor/MKS-ODrive)

Diff toàn bộ `Firmware/` của gói `ODriveMINI-fw-v0.5.1-20250326.rar` so với `fw-v0.5.1` gốc:

1. `tup.config`: `CONFIG_BOARD_VERSION=v3.6-56V`.
2. `main.cpp`: chỉ gọi `axes[0]->motor_.setup()` (không setup DRV8301 của axis 1).
3. `encoder.cpp`:
   - `is_ready_ = true` khi `pre_calibrated` với mọi mode ≠ INCREMENTAL;
   - bỏ dòng reset `pre_calibrated = false` trong `check_pre_calibrated()`;
   - **bỏ hẳn kiểm tra parity + error flag** của AS5047P.

Mục (3a) và (3b) **đã có sẵn trong 0.5.6** (`abs_spi_cb()` tự đặt `is_ready_ = true`
khi `pre_calibrated` và nhận được mẫu SPI hợp lệ; `check_pre_calibrated()` chỉ chạy khi
người dùng set thuộc tính). Mục (3c) là hack che lỗi: AS5047P **chốt (latch) cờ EF**
(bit 14) sau bất kỳ lỗi truyền nào cho tới khi thanh ghi `ERRFL` được đọc, mà ODrive
gốc không bao giờ đọc `ERRFL` → chỉ cần một glitch (ví dụ lúc DRV8301 khởi tạo trên
cùng bus SPI3) là mọi mẫu sau đó đều bị loại. Port này giữ nguyên kiểm tra parity/EF
nhưng **tự động đọc `ERRFL` để xóa cờ**.

## 3. Thay đổi trong port 0.5.6 này

Tất cả đều nằm sau macro `MKS_XDRIVE_MINI` (bật bởi board `mks-xdrive-mini` trong
`Tupfile.lua`). Build với `CONFIG_BOARD_VERSION=v3.6-56V` vẫn cho ra firmware ODrive gốc.

| File | Thay đổi |
|---|---|
| `Tupfile.lua` | thêm board `mks-xdrive-mini` = v3.6-56V + `-DMKS_XDRIVE_MINI=1` |
| `Board/v3/Inc/board.h` | **`AXIS_COUNT = 1`** khi `MKS_XDRIVE_MINI`; `MKS_ONBOARD_ENCODER_CS_GPIO=7`, `MKS_ONBOARD_ENCODER_CPR=16384`, `MKS_AS5047_ERRFL_AUTOCLEAR` |
| `Board/v3/board.cpp` | `m1_gate_driver`, phần tử thứ 2 của `fet_thermistors/motors/encoders/axes` và mọi `motors[1].*` trong ISR đặt sau `#if AXIS_COUNT >= 2`; các lệnh disarm-all dùng `for (auto& motor : motors)`. TIM8 vẫn chạy vì là trigger ADC/ISR |
| `filter_interface.py` + `Tupfile.lua` | board `mks-xdrive-mini` có `axis_count=1`; Tupfile sinh `autogen/odrive-interface.yaml` (bỏ dòng `axis1`) và đưa file đó vào 4 rule interface generator → **không còn endpoint `odrv0.axis1`** |
| `MotorControl/encoder.cpp/.hpp` | AS5047P: state machine tự đọc `ERRFL` khi thấy EF (và một lần lúc boot); default `abs_spi_cs_gpio_pin = 7`, `cpr = 16384` |
| `odrive-interface.yaml` | thêm `axisN.encoder.spi_error_flag_count` (readonly) để chẩn đoán |
| `MotorControl/odrive_main.h` | `otp_valid_ = true` khi build với `CONFIG_NO_DRM=true` (xem mục 6) |
| `MotorControl/motor.cpp/.hpp` | `config.max_dc_calib_ratio` (mặc định 0.1 = upstream) thay cho hằng 0.1; endpoint chẩn đoán `dc_calib_valid`, `dc_calib_running_since` (xem mục 7) |

Phần còn lại của firmware (`main.cpp`, `axis.cpp`, `motor.cpp`, `low_level.cpp`,
`ascii_protocol.cpp`, `can_simple.cpp`) đã được viết theo `AXIS_COUNT` nên không cần
sửa. Kết quả với GCC 13: flash 317 KB → **269 KB**, RAM tĩnh (bss) 143.6 KB →
**127.1 KB**, bớt 1 thread RTOS và toàn bộ phần xử lý axis 1 trong control loop.

## 4. Build

```bash
cd Firmware
cp tup.config.mks tup.config      # hoặc sửa tup.config: CONFIG_BOARD_VERSION=mks-xdrive-mini
mkdir -p autogen
python ../tools/odrive/version.py --output autogen/version.c
tup init && tup
# -> build/ODriveFirmware.hex / .bin / .elf
```

Toolchain khuyến nghị: `gcc-arm-none-eabi 9-2019-q4` (theo docs ODrive) hoặc Docker
image trong repo. Bản `.hex` kèm theo được build bằng GCC 13.2 chỉ để xác nhận
biên dịch sạch; nên tự build lại bằng toolchain chính thức trước khi nạp.

Nạp: DFU (`odrivetool dfu build/ODriveFirmware.hex`) hoặc ST-Link/OpenOCD qua J2 (SWD).
Sau khi nạp fw khác major/minor, `odrv0.erase_configuration()`.

## 5. Cấu hình odrivetool

```python
# Encoder onboard AS5047P
odrv0.axis0.encoder.config.mode = ENCODER_MODE_SPI_ABS_AMS   # = 257
odrv0.axis0.encoder.config.abs_spi_cs_gpio_pin = 7           # default trong build này
odrv0.axis0.encoder.config.cpr = 16384                       # default trong build này
odrv0.config.gpio7_mode = GPIO_MODE_DIGITAL                  # default

# Motor (ví dụ), brake resistor như ODrive v3.6
odrv0.config.enable_brake_resistor = True
odrv0.config.brake_resistance = 2.0
odrv0.axis0.motor.config.pole_pairs = 7
odrv0.axis0.motor.config.calibration_current = 10
odrv0.axis0.motor.config.current_lim = 10
odrv0.axis0.motor.config.torque_constant = 8.27 / 270

odrv0.save_configuration()   # reboot
odrv0.axis0.requested_state = AXIS_STATE_FULL_CALIBRATION_SEQUENCE
# sau khi OK:
odrv0.axis0.motor.config.pre_calibrated = True
odrv0.axis0.encoder.config.pre_calibrated = True
odrv0.save_configuration()
```

Kiểm tra encoder: `odrv0.axis0.encoder.spi_error_rate` (nên ~0) và
`odrv0.axis0.encoder.spi_error_flag_count` (tăng liên tục = lỗi bus/magnet).

`odrv0.axis1` không tồn tại trong build này.

## 6. "Not a genuine ODrive" / thiết bị hiện là `dev0` thay vì `odrv0`

Nguyên nhân: `odrv.otp_valid_` = byte đầu vùng OTP của STM32 (`0x1FFF7800`) ≠ `0xFF`.
ODrive Robotics ghi OTP lúc sản xuất; board clone để trống → firmware báo
`otp_valid = False` → `odrivetool` (`shell.py`, hàm `mount`) in cảnh báo và đặt tên
`dev0`. **Đây là toàn bộ hệ quả**: không có tính năng nào trong firmware 0.5.6 hay
odrivetool 0.5.x bị tắt; `odrive.find_any()` trong script Python vẫn hoạt động bình
thường. Khi OTP trống, firmware dùng `fake_otp` trong RAM nên `hw_version` vẫn báo
3.6 / 56 V.

Ba cách xử lý, chọn một:

1. **Firmware (mặc định trong build này):** `CONFIG_NO_DRM=true` trong `tup.config`
   → `-DNO_DRM` → `otp_valid_ = true` → odrivetool mount thành `odrv0`.
   Nếu muốn giữ đúng bản chất (báo là clone), đặt `CONFIG_NO_DRM=false`.
2. **Phía odrivetool, không đổi firmware:** trong shell gõ `odrv0 = dev0`, hoặc sửa
   `odrive/shell.py` (thư mục site-packages) — trong `mount()` đổi
   `return ("device " + serial_number_str, "dev")` thành
   `return ("ODrive " + serial_number_str, "odrv")`.
3. **Ghi OTP bằng ST-Link/OpenOCD** (vĩnh viễn, không khuyến nghị): ghi 6 byte
   `00 00 00 03 06 38` (major=3, minor=6, voltage=56) vào `0x1FFF7800`. Chỉ làm
   nếu bạn hiểu rõ OTP không thể xóa.

## 7. `MOTOR_ERROR_UNKNOWN_CURRENT_MEASUREMENT` khi calibration (axis error 0x40)

`0x40` = `AXIS_ERROR_MOTOR_FAILED` (odrivetool 0.5.4 không in tên, chỉ báo UNKNOWN).
Lỗi thật nằm ở motor: khi arm, `current_meas_` không có giá trị. Trong 0.5.6
(`Motor::current_meas_cb`) mẫu dòng chỉ hợp lệ khi **cả hai** điều kiện đúng:

1. `dc_calib_running_since >= 7.5 * config.dc_calib_tau` (mặc định 1.5 s) — bộ đếm
   này bị reset về 0 mỗi khi DRV8301 báo chưa sẵn sàng hoặc ADC bão hòa;
2. `|DC_calib_phA/B/C| < max_dc_calib`, với `max_dc_calib = max_dc_calib_ratio *
   max_allowed_current` (upstream cố định 0.1 → tương đương offset ~121 mV tại ADC,
   không phụ thuộc gain).

fw 0.5.1 (bản MKS dùng) **không có** kiểm tra này, chỉ trừ offset đi — nên board
chạy được với 0.5.1 nhưng fail với 0.5.6 nếu shunt amplifier của DRV8301 (hoặc bản
clone của nó) có offset lớn.

Chẩn đoán (để board idle ≥ 3 s sau khi cấp nguồn, không cần motor quay):

```python
m = odrv0.axis0.motor
print(m.dc_calib_valid, m.dc_calib_running_since)
print(m.DC_calib_phB, m.DC_calib_phC, m.max_dc_calib, m.max_allowed_current)
print(m.n_evt_current_measurement)   # phải tăng ~8000/s
print(hex(m.error), hex(odrv0.axis0.error))
```

Đọc kết quả:

| Quan sát | Nguyên nhân | Xử lý |
|---|---|---|
| `dc_calib_running_since` cứ nhỏ / về 0 | DRV8301 mất ready (nFAULT nhấp nháy) hoặc ADC bão hòa (sẽ kèm `CURRENT_SENSE_SATURATION`) | kiểm tra nguồn PVDD/GVDD, nFAULT PD2, tụ bootstrap |
| `running_since` > 1.5 nhưng `|DC_calib_phB/C| > max_dc_calib` | offset shunt amp lớn (hay gặp trên clone) | `odrv0.axis0.motor.config.max_dc_calib_ratio = 0.3` (có hiệu lực ngay, không cần reboot) rồi `save_configuration()`. Nếu phải > 0.5 thì phần cứng có vấn đề (REF/AVCC, SP/SN, shunt) |
| `DC_calib_phB` ≈ ±`max_allowed_current` | shunt amp bão hòa / chân SP-SN hở | kiểm tra R13/R15 120 R, shunt 0.5 mΩ |
| `n_evt_current_measurement` không tăng | control loop không chạy | lỗi timer/ADC, xem `dump_timing` |

**Bẫy phase A (đã sửa trong port này):** upstream kiểm tra cả `DC_calib_phA`, nhưng
trên board v3.x chỉ có 2 sensor (B, C) và `phA = -(phB + phC)` — offset "ảo" của A là
tổng hai offset thật nên có thể vượt ngưỡng dù B và C đều đạt. Ví dụ đo thực tế trên
MKS Mini: phB = −1.97 A, phC = −1.28 A, `max_dc_calib` = 3.04 A → phA = +3.25 A →
`dc_calib_valid = False`. Port này chỉ kiểm tra các pha có sensor thật
(`current_sensor_mask_`). Nếu chưa nạp bản sửa, workaround: `max_dc_calib_ratio = 0.15`.

Sau khi đổi fw, luôn `odrv0.erase_configuration()` (struct config đã thay đổi).

## 8. Tốc độ vòng điều khiển và axis 1

Mặc định (`Board/v3/Inc/main.h`): PWM 24 kHz (168 MHz / (2 × 3500)), dead-time
20 clk ≈ 119 ns, vòng dòng + encoder + vị trí/vận tốc đều 8 kHz (`RCR = 2`, tất cả
trong `control_loop_cb()`).

Port này xóa hẳn axis 1 (`AXIS_COUNT = 1`, "mức B"): không còn `odrv0.axis1` trong
odrivetool, `dump_errors` chỉ in axis0. Lưu ý phía host:

- Script/GUI cũ tham chiếu `odrv0.axis1` sẽ báo `AttributeError` — bỏ các tham chiếu đó.
- ASCII protocol: `p 1 ...`, `v 1 ...` trả về lỗi "invalid motor number" (kiểm tra
  `motor_number >= AXIS_COUNT` có sẵn).
- CAN: chỉ có một node_id (`axis0.config.can.node_id`).
- Config lưu trong flash đổi layout → `erase_configuration()` sau khi nạp.

Đo hiệu quả: `dump_timing(odrv0)` — `control_loop_misc/checks` và tổng
`axis0.task_times.*` là toàn bộ tải của ISR 125 µs.

Kết quả đo thực tế trên MKS Mini (bản B, closed loop, `dump_timing`; đơn vị tick
168 MHz, 1 chu kỳ = 21 000 tick = 125 µs):

| Đoạn | tick | µs |
|---|---|---|
| Trễ vào ISR → `sampling` | 0 – 1 800 | 10,7 |
| Phần 1: sampling … `current_controller_update` | 1 800 – 9 300 | 44,6 |
| `dc_calib_wait` (**chờ rảnh** mẫu ADC thứ 2 / reset CCR giữa chu kỳ) | 9 300 – 12 250 | 17,6 |
| Phần 2: `dc_calib` + `pwm_update` | 12 650 – 14 100 | 8,6 |
| Dư đến cuối chu kỳ | 14 100 – 21 000 | 41 |

CPU thực dùng ≈ 56 µs / 125 µs (45 %). Ràng buộc cứng là *phần 1 + phần 2 phải xong
trước update event kế tiếp*, còn phần 1 kết thúc sau điểm giữa chu kỳ chỉ làm mất
thời gian chờ chứ không lỗi.

Nâng tần số: **giữ `TIM_1_8_RCR = 2`** (RCR phải chẵn vì cơ chế lấy mẫu luân phiên
vector 0/7; RCR = 1 sẽ gây `ERROR_TIMER_UPDATE_MISSED`) và đổi `TIM_1_8_PERIOD_CLOCKS`
qua `tup.config`:

```
CONFIG_PWM_PERIOD_CLOCKS=2333     # 36 kHz PWM / 12 kHz control — bản phát hành (đo: dư ≥ 15 µs worst-case, USB bận không tăng jitter)
#CONFIG_PWM_PERIOD_CLOCKS=2800    # 30 kHz / 10 kHz — dự phòng, dư ~25 µs
#(bỏ dòng)                        # 24 kHz / 8 kHz — stock
```

Kết quả đo 12 kHz (chu kỳ 14 000 tick): phần 1 kết thúc 8 350, `dc_calib_wait` ≈ 0,
`pwm_update` 9 250 – 10 500, dư 20,8 µs trung bình / ≈ 15 µs worst-case; FET +3 °C so
với 10 kHz khi không tải. 15 kHz không khả thi (xem phần "trần" bên dưới).

Trần của kiến trúc này trên F405: `RCR` phải chẵn (luân phiên đáy/đỉnh để đo dòng và
DC-offset), nên control = PWM / 3; khối lượng tính toán ≈ 56 µs/chu kỳ là hằng số →
15 kHz (66,7 µs) không còn biên. Muốn control/PWM = 1/2 (ví dụ 15/30) phải thiết kế
lại cơ chế đo DC-offset (đóng băng khi armed) *và* cắt ~20 % ISR — không nằm trong
phạm vi port này.

Sau khi nạp bản tần số khác: `erase_configuration()` không bắt buộc nhưng nên chạy
lại `FULL_CALIBRATION_SEQUENCE`; theo dõi `dump_errors` (`CONTROL_DEADLINE_MISSED`,
`BAD_TIMING`) và nhiệt FET (`axis0.motor.fet_thermistor.temperature`) vì tổn hao
chuyển mạch tăng 25 %.

## 9. Nếu vẫn gặp `ENCODER_ERROR_ABS_SPI_COM_FAIL`

Thứ tự thử:
1. Xem `spi_error_flag_count` có tăng không. Tăng nhanh → nam châm lệch/xa, hoặc bus.
2. Giảm tốc độ SPI3 cho encoder: `SPI_BAUDRATEPRESCALER_16` → `_32` trong
   `Encoder::setup()` (chưa đổi trong port này).
3. Chỉ khi cần mới nới ngưỡng `spi_error_rate_ > 0.05f` trong `Encoder::update()`.
4. Cách của MKS (bỏ hẳn parity/EF check) là phương án cuối cùng — nó ẩn lỗi thật.
