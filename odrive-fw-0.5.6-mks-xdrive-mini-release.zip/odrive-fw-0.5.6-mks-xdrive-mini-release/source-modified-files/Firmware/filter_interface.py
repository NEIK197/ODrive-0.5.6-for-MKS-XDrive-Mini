#!/usr/bin/env python3
"""
Produce a filtered copy of odrive-interface.yaml for single-axis boards
(MKS XDrive Mini): removes the `axis1` endpoint from the root interface so
that the generated endpoint table does not reference a non-existent object.

Usage: filter_interface.py --input odrive-interface.yaml --output autogen/odrive-interface.yaml --axis-count 1
"""
import argparse, re

p = argparse.ArgumentParser()
p.add_argument('--input', required=True)
p.add_argument('--output', required=True)
p.add_argument('--axis-count', type=int, default=2)
args = p.parse_args()

pat = re.compile(r'^\s*axis(\d+):\s*\{type:\s*ODrive\.Axis\b')
out = []
with open(args.input, 'r', encoding='utf-8') as f:
    for line in f:
        m = pat.match(line)
        if m and int(m.group(1)) >= args.axis_count:
            continue
        out.append(line)
with open(args.output, 'w', encoding='utf-8', newline='\n') as f:
    f.writelines(out)
